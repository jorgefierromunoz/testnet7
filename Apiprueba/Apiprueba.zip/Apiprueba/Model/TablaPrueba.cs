﻿namespace Apiprueba.Model
{
    public class TablaPrueba
    {
        public int Id { get; set; }
        public string ColumnaPrueba { get; set; }
    }
}
